import { Form, SubmissionGrid } from '@formio/react';
import React, { useEffect, useState } from 'react'
// import MyForm from './MyForm';


// const renderForm = () => {
//     Formio.createForm(document.getElementById('formio'), 'https://examples.form.io/example').then(function(form) {
//   // Defaults are provided as follows.
//     form.submission = {
//         data: {
//         firstName: 'Joe',
//         lastName: 'Smith'
//         }
//     };

//     // Register for the submit event to get the completed submission.
//     form.on('submit', function(submission) {
//         console.log('Submission was made!', submission);
//     });

//     // Everytime the form changes, this will fire.
//     form.on('change', function(changed) {
//         console.log('Form was changed', changed);
//     });
//     });
// }




const Form1 = () => {
  // let [submission, setSubmission] = useState(null);
  
  const onSubmit = (submitted) => {
    let response = JSON.stringify(submitted.data);
    console.log('Submitted data: ', response);
    localStorage.setItem('DemoSurveyResponse', response);
  }

  const formSchema = {
    components: [
      {
        type: "textfield",
        key: 'firstName',
        label: 'First Name',
        input: true,
      },
      {
        type: "textfield",
        key: 'lastName',
        label: 'Last Name',
        input: true,
      },
      {
        type: 'button',
        label: 'Submit',
        key: 'submit',
        disableOnInvalid: true,
      },
    ],
  };

  return (
    <>
      <p>Demo Form : </p>
      <Form src={formSchema} onSubmit={onSubmit} />
    </>
  )
}

export default Form1