import React from 'react'
import { Form } from '@formio/react'

const RenderResponse = () => {
    let schema = localStorage.getItem('surveySchema');
    let parsedSchema = JSON.parse(schema);

    let response = localStorage.getItem('DemoSurveyResponse');
    let parsedResponse = JSON.parse(response);

    
    // let data = {
    //     jobTitle: 'test',
    //     poNumber: 1234,
    // }


    return (
        <>

            <Form src={parsedSchema} submission={{data: parsedResponse}} options={{readOnly: true}}  />
        
        </>
    )
}

export default RenderResponse