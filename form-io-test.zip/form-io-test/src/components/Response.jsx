import React from 'react'
import { styled } from '@mui/material/styles';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { Grid } from '@mui/material';
import '../styles/response.css';

const Response = () => {
    // let response = localStorage.getItem('surveyResponse');
    let response = JSON.parse(localStorage.getItem('DemoSurveyResponse'));
    let keysArray = [];
    let valuesArray = [];
    Object.keys(response).forEach((key, index) => {
        keysArray.push(key);
    });
    console.table(keysArray, valuesArray);


    return (
        <>
            <div style={{'fontSize': '20px', fontWeight: 700, textAlign: 'center', marginBottom: '30px', marginTop: '20px'}}>User Response</div>


            <Grid className='grid-bg' container spacing={3}>
                {keysArray.map((element, idx) => <Grid key={idx} item xs={6}>
                                        <p className='bg'>
                                            {element}
                                        </p>
                                        <input className='input1' type="text" contentEditable="false" value={`${response[element]}`} />
                                    </Grid>)}
            </Grid>
        </>
    )
}

export default Response