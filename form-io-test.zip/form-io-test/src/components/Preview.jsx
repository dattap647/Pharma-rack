import React from 'react'
import { Form } from '@formio/react'


const Preview = () => {
    let schema = localStorage.getItem('surveySchema');
    let parsedSchema = JSON.parse(schema);
    // console.log('schema: ', schema);

    return (
        <>

            <Form src= {parsedSchema}  options={{ readOnly: true }} />


        </>
    )
}

export default Preview