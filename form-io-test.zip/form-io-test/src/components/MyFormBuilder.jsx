import React, { useEffect } from 'react';
import { FormBuilder, Formio } from '@formio/react'
// import {Formio} from 'formiojs'
// import semantic from '@formio/semantic';
// import Snackbar from '@mui/material/Snackbar';
// import IconButton from '@mui/material/IconButton';
// import CloseIcon from '@mui/icons-material/Close';
// import Button from '@mui/material/Button';


import CustomInput from './CustomInput';


import '../styles/formBuilder.css';
import { useNavigate } from 'react-router-dom';

const MyFormBuilder = () => {
  let schema = JSON.parse(localStorage.getItem('surveySchema'));
  if(!!schema) {
    schema = schema['components'];
  }
  let savedSchema = {
    "title": "Survey",
    "display": "form",
    "type": "form",
    "name": "survey1",
    "components": schema
  };
  const navigate = useNavigate();
  let updatedSchema;

  Formio.use({
    components: {
      custom1: CustomInput
    }
  });


  const submission = {
    data: {}
  };

  const fillTextArea = () => {
    let template = JSON.stringify(updatedSchema);
    document.getElementById('template').innerText = template;
  }

  const save = () => {
    let template = JSON.stringify(updatedSchema);
    localStorage.setItem("surveySchema", template);
    alert('saved');
  }

  const preview = () => {
    navigate('/preview');
  }

  const fill = () => {
    navigate('/survey');
  }

  const onChange = (newSchema) => {
    updatedSchema = newSchema;
    // save();
    console.log('changed')
  }


  const builderComponent = function (ctx) {
    return `<div class="builder-component" ref="dragComponent" tabindex="-1">
          <div class="component-btn-group" data-noattach="true">
            <div
              role="button"
              aria-label="Remove button. Click to remove component from the form"
              tabindex="-1"
              class="btn btn-xxs btn-danger component-settings-button component-settings-button-remove"
              ref="removeComponent"
            >
              <i class="${ctx.iconClass('remove')}"></i>
            </div>
            <div
              role="button"
              aria-label="Copy button. Click to copy component"
              tabindex="-1"
              class="btn btn-xxs btn-default component-settings-button component-settings-button-copy"
              ref="copyComponent"
            >
              <i class="${ctx.iconClass('copy')}"></i>
            </div>
            <div
              role="button"
              aria-label="Paste below button. Click to paste component below the current component"
              tabindex="-1"
              class="btn btn-xxs btn-default component-settings-button component-settings-button-paste"
              ref="pasteComponent"
            >
              <i class="${ctx.iconClass('save')}"></i>
            </div>
            <div
              role="button"
              aria-label="Move button"
              tabindex="-1"
              class="btn btn-xxs btn-default component-settings-button component-settings-button-move"
              ref="moveComponent"
            >
              <i class="${ctx.iconClass('move')}"></i>
            </div>
            <div
              role="button"
              aria-label="Edit button. Click to open component settings modal window"
              tabindex="-1"
              class="btn btn-xxs btn-secondary component-settings-button component-settings-button-edit"
              ref="editComponent"
            >
              <i class="${ctx.iconClass('cog')}"></i>
            </div>
          </div>
        ${ctx.html}
      </div>`;
  };


  return (
    <div className='form-builder-container'>

      <div className='top-context-menu'>
        <div role="button" onClick={() => navigate('/')}>EDITOR <span className='active-context'></span> </div>
        {/* <div role="button" onClick={() => console.log('Clicked Settings')}>SETTINGS</div>
            <div role="button" onClick={() => console.log('Clicked Themes')}>THEMES</div>
            <div role="button" onClick={() => console.log('Clicked Integrations')}>INTEGRATIONS</div> */}
        <div role="button" onClick={fill}>LAUNCH</div>
        <div role="button" onClick={preview}>PREVIEW</div>
        <div role="button" onClick={save}>SAVE</div>
      </div>

      <FormBuilder
        form={{ ...savedSchema }}
        // src={savedSchema}
        submission={{}}
        onChange={onChange}
        options={{
          builder: {
            customBasic: {
              title: 'Basic Components',
              default: true,
              weight: 0,
              key: 'basicComponents',
              components: {
                textfield: true,
                textarea: true,
                email: true,
                phoneNumber: true,
                file: true,
                button: true,
                table: true,
                survey: true,
                time: true,
                day: true,
                password: true,
              },
            },
            basic: false,
            advanced: false,
            layout: false,
            data: false,
            premium: false,
          },
          templates: {
            builderComponent: { form: builderComponent },
            // 'builderSidebar': {form: (ctx) => `<div class='test123456'>test</div>`}
            'builderSidebarGroup-basic': {form: (ctx) => `<div class='test123456'>test</div>`}
            // 'component'
            // 'components'
            // 'input'
            // 'input-password'
            // 'file'
          },
        }}
      />

    </div>
  )
}

export default MyFormBuilder