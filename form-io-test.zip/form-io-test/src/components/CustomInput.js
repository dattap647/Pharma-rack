import React from 'react'
import { Components } from "@formio/react";
import { TextField } from '@mui/material';

const Input = Components.components.input;

class CustomInput extends Input {


    static schema(...extend) {
        return Input.schema({
            type: 'custom1',
            label: 'My Custom',
            key: 'custom1',
        });
    }


    // the schema to define how the component will look
    // on the LHS formbuilder.
    static get builderInfo() {
        return {
            title: 'Custom 1',
            icon: 'star',
            group: 'basic',
            weight: 200,
            schema: CustomInput.schema()
        };
    }


    constructor(component, options, data) {
        super(component, options, data);
    }


    init() {
        super.init();
    }


    get inputInfo() {
        const info = super.inputInfo;
        return info;
    }


    render(content) {
        return super.render('<div ref="customRef">This is a custom component!</div>');
    }


    attach(element) {
        this.loadRefs(element, {
            customRef: 'single',
        });


        this.addEventListener(this.refs.customRef, 'click', ()=> {
            console.log('Custom ref has been clicked!!');
        });

        return super.attach(element);
    }


    detach() {
        return super.detach();
    }


    destroy() {
        return super.destroy();
    }


    normalizeValue(value, flags = {}) {
        return super.normalizeValue(value, flags);
    }


    getValue() {
        return super.getValue();
    }


    getValueAt(index) {
        return super.getValueAt(index);
    }


    setValue(value, flags= {}) {
        return super.setValue(value, flags);
    }


    setValueAt(index, value, flags= {}) {
        return super.setValueAt(index, value, flags);
    }


    updateValue(value, flags = {}) {
        return super.updateValue(value, flags);
    }


    updateValueAt(index, value, flags = {}) {
        return super.updateValueAt(index, value, flags);
    }
}

export default CustomInput