import React from 'react'
import {Form, Formio} from '@formio/react'
// import semantic from '@formio/semantic'


import CustomInput from './CustomInput';
import { useNavigate } from 'react-router-dom';

const MyForm = () => {
    const navigate = useNavigate();

  // Formio.use(semantic);
    Formio.use({
      components: {
        custom1: CustomInput,
      }
    });

    let formSchema = JSON.parse(localStorage.getItem('surveySchema'));

    const onSubmit = (submitted) => {
      let response = JSON.stringify(submitted.data);
      console.log('Submitted data: ', response);
      localStorage.setItem('DemoSurveyResponse', response);

      navigate('/render');
    }

  return (
    <>
    <p style={{'color': 'black', fontWeight: 700, fontSize: "20px", textAlign: 'center'}}>Job form</p>
    <Form src={formSchema} onSubmit={onSubmit} />
    </>
  )
}

export default MyForm