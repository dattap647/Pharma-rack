
import './App.css'
import Form1 from "./components/Form1";
import MyForm from './components/MyForm';
import MyFormBuilder from './components/MyFormBuilder';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Response from './components/Response';
import Preview from './components/Preview';
import RenderResponse from './components/RenderResponse';
import DefaultFormBuilder from './components/DefaultFormBuilder';
import TableNavigation from './components/TableNavigation';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  
  const router = createBrowserRouter([
    {
      path: "/",
      element: <MyFormBuilder />
    },
    {
      path: "/create",
      element: <MyFormBuilder />
    },
    {
      path: "/survey",
      element: <MyForm />
    },
    {
      path: "/demo",
      element: <Form1 />
    },
    {
      path: "/response",
      element: <Response />
    },
    {
      path: "/preview",
      element: <Preview />
    },
    {
      path: "/render",
      element: <RenderResponse />
    },
    {
      path: "/default_builder",
      element: <DefaultFormBuilder />
    },
  ]);

  return (
    <>
      <TableNavigation />
      {/* <p>Form testing</p> */}
      <RouterProvider router={router} />
      {/* <MyForm /> */}
      {/* <Form1 /> */}
      {/* <MyFormBuilder /> */}
    </>
  )
}

export default App
